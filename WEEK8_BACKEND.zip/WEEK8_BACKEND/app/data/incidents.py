import pandas as pd
from app.data.db import connect_database

def insert_incident(date_reported, incident_type, severity, status, description, reported_by):
    """Insert a new cyber incident"""
    try:
        conn = connect_database()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO cyber_incidents 
            (date_reported, incident_type, severity, status, description, reported_by)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (date_reported, incident_type, severity, status, description, reported_by))
        
        incident_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return incident_id
    except Exception as e:
        print(f"Error inserting incident: {e}")
        return None

def get_all_incidents():
    conn = connect_database()
    df = pd.read_sql_query("SELECT * FROM cyber_incidents", conn)
    conn.close()
    return df
def update_incident_status(incident_id, new_status):
    conn = connect_database()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE cyber_incidents SET status = ? WHERE id = ?",
        (new_status, incident_id)
    )
    conn.commit()
    conn.close()

def delete_incident(incident_id):
    conn = connect_database()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM cyber_incidents WHERE id = ?", (incident_id,))
    conn.commit()
    conn.close()