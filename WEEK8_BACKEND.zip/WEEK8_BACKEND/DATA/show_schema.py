import sqlite3
from pathlib import Path

# 👉 Update this if your path is different
DB_PATH = Path("WEEK8_BACKEND/DATA/intelligence_platform.db")

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

print("\n📌 TABLE STRUCTURES (PRAGMA)")
print("-----------------------------------")

tables = ["cyber_incidents", "it_tickets", "datasets_metadata"]

for table in tables:
    print(f"\n🔽 {table}:")
    cur.execute(f"PRAGMA table_info({table})")
    for row in cur.fetchall():
        print(row)

conn.close()
